package com.example.weighttracker;

import android.content.Context;

import com.example.weighttracker.DailyWeight;
import com.example.weighttracker.GoalWeight;
import com.example.weighttracker.User;

public abstract class Database {

    private static final String DATABASE_NAME = "weightTracker.db";
    private static Database mWeightTrackerDatabase;
    // Singleton pattern
    public static Database getInstance(Context context) {
        if (mWeightTrackerDatabase == null) {
            mWeightTrackerDatabase = Room.databaseBuilder(context, Database.class,
                        DATABASE_NAME).allowMainThreadQueries().build();
            }
            return mWeightTrackerDatabase;
    }
}
