package com.example.weighttracker;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.example.weighttracker.Database;
import com.example.weighttracker.User;

import java.util.List;

public class Login {
    public class LoginActivity extends AppCompatActivity {

        private Database mWeightTrackerDb;
        private User mUser;
        private TextView mFeedback;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.sign_in);

            // get singleton instance of database
            mWeightTrackerDb = Database.getInstance(getApplicationContext());
        }


        /**
         * Login button callback
         * Searches User table for credentials input
         * Authenticates user and starts WeightActivity
         */
        public void onLoginClick(View view) {
            // get user input from EditText fields
            String username = ((EditText) findViewById(R.id.usernameText)).getText().toString();
            String password = ((EditText) findViewById(R.id.passwordText)).getText().toString();

            // search SQLite database for matching username and password
            boolean isAuthenticated = login(username, password);
            if (isAuthenticated) {
                mUser = new User(username, password);
            }
        }

        public void onCreateAccountClick(View view) {

            // get user input from EditText fields
            String username = ((EditText) findViewById(R.id.usernameText)).getText().toString();
            String password = ((EditText) findViewById(R.id.passwordText)).getText().toString();


            //if user input is not blank
            if (!username.isEmpty() && !password.isEmpty()) {
                List<User> userList = User.getUsername();
                boolean found = false;
                //check if username is already taken
                if (userList.size() > 0) {
                    for (int i = 0; i < userList.size(); i++) {
                        if (userList.get(i).getUsername().equals(username)) {
                            found = true;
                        }
                    }
                }
                //if username is not in the database already
                if (!found) {
                    new User(username, password);
                }
            }
        }
        //Search in db for matching username and password
        private boolean login(String username, String password) {
            List<User> userList = User.getUsername();
            for (int i = 0; i < userList.size(); i++) {
                if (userList.get(i).getUsername().equals(username) &&
                        userList.get(i).getPassword().equals(password)) {
                    return true;
                }
            }
            return false;
        }
    }
}
