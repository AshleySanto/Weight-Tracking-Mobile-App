package com.example.weighttracker;

public class GoalWeight {
    private int id;
    private String username;
    private double goal;

    // Constructors
    public GoalWeight() {}

    public GoalWeight(double goal, String username) {;
        this.username = username;
        this.goal = goal;
    }

    // Getters
    public int getId() {
        return id;
    }
    public String getUsername() {
        return username;
    }
    public double getGoal() {
        return goal;
    }

    // Setters
    public void setId(int id) {
        this.id = id;
    }
    public void setUsername(String username) {
        this.username = username;
    }
    public void setGoal(double goal) {
        this.goal = goal;
    }
}
