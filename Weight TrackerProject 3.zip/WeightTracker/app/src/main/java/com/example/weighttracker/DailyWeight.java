package com.example.weighttracker;

import java.util.Date;

public class DailyWeight {
    private int id;
    private Date date;
    private double weight;
    private String username;

    // Constructors
    public DailyWeight() {}

    public DailyWeight(Date date, double weight, String username) {
        this.date = date;
        this.weight = weight;
        this.username = username;
    }


    // Getters
    public int getId() {
        return id;
    }
    public Date getDate() {
        return date;
    }
    public double getWeight() {
        return weight;
    }
    public String getUsername() {
        return username;
    }

    // Setters
    public void setId(int id) {
        this.id = id;
    }
    public void setDate(Date date) {
        this.date = date;
    }
    public void setWeight(double weight) {
        this.weight = weight;
    }
    public void setUsername(String username) {
        this.username = username;
    }
}


